import React from 'react';

function JobTiles() {
  return (
    <div>
      <h1>Job Tiles</h1>
    </div>
  );
}

export default JobTiles;
