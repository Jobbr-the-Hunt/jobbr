import { Request, Response, NextFunction } from 'express';
// import { LogoutController, ServerError } from '../../types';

// const logoutController: LogoutController = {};

// export default logoutController;