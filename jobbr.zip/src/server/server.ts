import path from 'path';
const express = require('express');
import { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import cookieParser from 'cookie-parser';

import signupRouter from './routes/signupRouter';
import loginRouter from './routes/loginRouter';
import logoutRouter from './routes/logoutRouter';
import jobRouter from './routes/jobRouter';

import { ServerError } from '../types';

const app = express();

const MONGO_URI =
  'mongodb+srv://codesmith:Codesmith123@cluster0.mg4yveh.mongodb.net/?retryWrites=true&w=majority';

mongoose
  .connect(MONGO_URI)
  .then(() => console.log('Connected to Mongo DB.'))
  .catch((err) => console.log(err));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// const corsOptions = {
//   origin: 'http://localhost:8080',
//   credentials: true,
//   optionSuccessStatus: 200
// };
app.use(express.static(path.resolve(__dirname, '../../dist')));
// app.use('/build', express.static(path.resolve(__dirname, '../../dist')));
// app.use(cors(corsOptions));

app.use(cookieParser());

app.use('/signup', signupRouter);
app.use('/login', loginRouter);
app.use('/logout', logoutRouter);
app.use('/job', jobRouter);

app.use(
  '/',
  (err: ServerError, req: Request, res: Response, next: NextFunction) => {
    const defaultErr: ServerError = {
      log: 'Express error handler caught unknown middleware error',
      status: 400,
      message: { err: 'An error occurred' },
    };
    const errorObj = Object.assign({}, defaultErr, err);
    console.log(errorObj.log);
    return res.status(errorObj.status).json(errorObj.message);
  }
);

app.listen(3000, () => console.log('server is listening on port 3000'));
